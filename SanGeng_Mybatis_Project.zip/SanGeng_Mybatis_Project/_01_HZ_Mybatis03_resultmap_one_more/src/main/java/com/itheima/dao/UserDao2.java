package com.itheima.dao;

import com.itheima.domain.User;

public interface UserDao2 {
    User selectById(Integer id);
}
