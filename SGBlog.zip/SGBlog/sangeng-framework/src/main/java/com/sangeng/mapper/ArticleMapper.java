package com.sangeng.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sangeng.domain.entity.Article;

public interface ArticleMapper extends BaseMapper<Article> {


}
