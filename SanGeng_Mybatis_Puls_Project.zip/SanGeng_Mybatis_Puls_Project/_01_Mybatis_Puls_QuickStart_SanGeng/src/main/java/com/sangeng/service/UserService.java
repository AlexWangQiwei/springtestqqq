package com.sangeng.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.sangeng.domian.User;

import java.util.List;

public interface UserService extends IService<User> {

//    List<User> list();

    User test();
}
