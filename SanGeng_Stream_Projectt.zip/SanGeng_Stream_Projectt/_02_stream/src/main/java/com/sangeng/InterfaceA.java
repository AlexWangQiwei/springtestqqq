package com.sangeng;
@FunctionalInterface
public interface InterfaceA {
    void test();
}
